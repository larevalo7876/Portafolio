#include "sound.h"
#include <stdint.h>
#include "tm4c123gh6pm.h"
#include "PLL.h"
#include "piano.h"
#include "DAC.h"
#include "LED.h"
//Global variables
uint32_t wave = 0;
uint32_t time = 0;
uint32_t count = 0;
int32_t i = 0;
int32_t sw = 0;
// Sound will hold each value of the sine wave array
int32_t sound[64] = {0x20,0x23,0x26,0x29,0x2c,0x2e,0x31,0x33,
0x36,0x38,0x3a,0x3b,0x3d,0x3e,0x3e,0x3f,
0x3f,0x3f,0x3e,0x3e,0x3d,0x3b,0x3a,0x38,
0x36,0x33,0x31,0x2e,0x2c,0x29,0x26,0x23,
0x20,0x1c,0x19,0x16,0x13,0x11,0xe,0xc,
0x9,0x7,0x5,0x4,0x2,0x1,0x1,0x0,
0x0,0x0,0x1,0x1,0x2,0x4,0x5,0x7,
0x9,0xc,0xe,0x11,0x13,0x16,0x19,0x1c};
void Sound_Init(void){
	//Initiate SysTick
	int x = 5;
	NVIC_ST_CTRL_R = 0;						//Disable SysTick before setting it up
	NVIC_ST_RELOAD_R = 0x00;			//Clearing reload values
	NVIC_ST_CURRENT_R = 0;				//Clearing Current_R
	NVIC_SYS_PRI3_R = 0xA0000000; // priority 5
	NVIC_ST_CTRL_R = 0x07;				//Enable SysTick with Interrupts
}	

void Sound_Play(unsigned long note){
	count = 50000000/(note*64);				//Get count number by dividing bus frequency by the array size times the note frequency
	NVIC_ST_RELOAD_R = count - 1;
	NVIC_ST_CURRENT_R = 0;						//Clear CURRENT_R
}
void GPIOPortA_Handler(void){
	uint32_t note=0;
	uint32_t l=0;
	sw = Piano_In();					//se holds the button pressed
	//Each button will be assigned a different note frequency
	if (sw == 0x04) {					//PA2 pressed
		note = 440;							//note A
		Sound_Play(note);				//Use note frequency on Sound_Play function to get count number for reload
		//output to light 0-5 to make letter A
		l = 0x77;
		LED_Out(l);
	}
				
	else if (sw == 0x08){			//PA3 pressed
		note = 494;							//note B
		Sound_Play(note);
		l = 0x7F;
		LED_Out(l);
	}
							
	else if (sw == 0x10){			//PA4 pressed
		note = 262;							//note C
		Sound_Play(note);
		l = 0x39;
		LED_Out(l);
	}
				
	else if (sw == 0x20){			//PA5 pressed
		note = 294;							//note D
		Sound_Play(note);
		l = 0x3F;
		LED_Out(l);
	}
	//when button is released the reload value should be 0 and the DAC will output 0
	else {	
		NVIC_ST_RELOAD_R = 0;
		NVIC_ST_CURRENT_R = 0;
		DAC_Out(0);
		l = 0x00;
		LED_Out(l);
	}
	GPIO_PORTA_ICR_R = 0xFF;	//Clearing the flag 
}	

void SysTick_Handler(void){

		//The DAC will output each value of the sine wave array
		DAC_Out(sound[i]);
		//Make sure that once the array hits the last value (64) it will go back to the first value
		i=(i+1)%64;							


}


