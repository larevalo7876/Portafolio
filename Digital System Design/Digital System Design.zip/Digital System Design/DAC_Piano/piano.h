//Function Prototypes
void Piano_Init (void);
unsigned long Piano_In (void);
void EnableInterrupts(void);

