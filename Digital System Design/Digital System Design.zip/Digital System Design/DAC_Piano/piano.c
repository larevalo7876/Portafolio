#include "piano.h"
#include <stdint.h>
#include "tm4c123gh6pm.h"
#include "PLL.h"
void Piano_Init (void){
	int x;
	SYSCTL_RCGCGPIO_R |= 0x01;          // 1) Port A clock
	x=5;
	//GPIO_PORTA_CR_R |= 0x3C;						//Allow changes PA2-PA5
	GPIO_PORTA_AMSEL_R &= ~0x3C;				//clear other bit
	GPIO_PORTA_AFSEL_R &= ~0x3C;				//clear other bit, C3
	GPIO_PORTA_DEN_R |= 0x3C;						//Enable digital I/O on PA2-PA5
	GPIO_PORTA_DIR_R &= ~0X3C;					//PA2-PA5 input
	//GPIO_PORTA_PUR_R = 0x3C;					//enable pull-up
	GPIO_PORTA_ICR_R = 0x3C;						//Clear Flag
	GPIO_PORTA_IS_R &= ~0x3C;						//PA2-5 are edge sensitive
	GPIO_PORTA_IBE_R |= 0x3C;						//Interrupt on both edges
	GPIO_PORTA_IM_R |= 0x3C;						//ARM INTERRUPTS
	NVIC_PRI0_R = 0x00000020;						//Giving Port A priority of 1
	NVIC_EN0_R = 0x00000001;						//Enable Interrupt for Port A
	EnableInterrupts();
}
unsigned long Piano_In (void){
	uint32_t sw = 0;										
	sw = GPIO_PORTA_DATA_R&0x3C;				//Give the 'sw' variable the switch that was pressed and then return it
	return sw;
}


