//Function Prototypes
void DAC_Init (void);
void DAC_Out(unsigned long data);

	
		//LED output voltage of 1.968V as LED can only take up to 2V, for this using the 37th value of array; 37*0.05238=1.938V
//		LED_Out(sound[36]);


