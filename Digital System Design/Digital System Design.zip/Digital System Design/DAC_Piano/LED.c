#include "LED.h"
#include <stdint.h>
#include "tm4c123gh6pm.h"

//			1		2
//		0		6		3
//			5		4

void LED_Init (void){
	int x;
	SYSCTL_RCGCGPIO_R |= 0x02;          // 1) Port B clock
	x=5;
	GPIO_PORTB_AMSEL_R &= ~0x7F;				//clear other bit
	GPIO_PORTB_AFSEL_R &= ~0x7F;				//clear other bit, C0
	GPIO_PORTB_CR_R |= 0x7F;						//Allow changes PB0-PB6
	GPIO_PORTB_DEN_R |= 0x7F;						//Enable digital I/O on PB0-PB6
	GPIO_PORTB_DIR_R |= 0X7F;						//PB0-PB6 out
}

void LED_Out(unsigned long led){
	GPIO_PORTB_DATA_R = led;						//Give the value of PortE_DATA_R to the global variable data
}

