//Function Prototypes
void Sound_Init(void);
void Sound_Play(unsigned long note);
void GPIOPortA_Handler(void);
void SysTick_Handler(void);

