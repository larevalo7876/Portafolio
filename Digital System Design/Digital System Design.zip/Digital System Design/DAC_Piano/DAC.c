#include "DAC.h"
#include <stdint.h>
#include "tm4c123gh6pm.h"
void DAC_Init (void){
	int x;
	SYSCTL_RCGCGPIO_R |= 0x10;          // 1) Port B clock
	x=5;
	GPIO_PORTE_AMSEL_R &= ~0x3F;				//clear other bit
	GPIO_PORTE_AFSEL_R &= ~0x3F;					//clear other bit, C0
	GPIO_PORTE_CR_R |= 0x3F;						//Allow changes PE0-PE5
	GPIO_PORTE_DEN_R |= 0x3F;						//Enable digital I/O on PE0-PE5
	GPIO_PORTE_DIR_R |= 0X3F;						//PE0-PE5 out
}
void DAC_Out(unsigned long data){
	GPIO_PORTE_DATA_R = data;						//Give the value of PortB_DATA_R to the global variable data
}


