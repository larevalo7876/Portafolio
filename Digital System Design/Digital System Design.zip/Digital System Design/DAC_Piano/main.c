// Documentation Section 
// main.c

// Runs on TM4C123 LaunchPad
// Input From: 
// Output to:
//
// 
// Author: Luis Arevalo
// Date: 10/22/2020
// Last modified: 

// 1. Pre-processor Directives Section
// Constant declarations to access port registers using 
// symbolic names instead of addresses
// include directives
#include <stdint.h>
#include "tm4c123gh6pm.h"
#include "PLL.h"
#include "DAC.h"
#include "piano.h"
#include "sound.h"
#include "LED.h"
// 2. Declarations Section
//   Global Variables
uint32_t data = 0;
uint32_t led = 0;
//uint32_t i = 0;
//   Insert Function Prototypes here
void WaitForInterrupt(void);
void EnableInterrupts(void);

// 3. Subroutines Section
// MAIN: Mandatory for a C Program to be executable

int main(void){
// Declare variables here
// Initialize the ports here
	PLL_Init();
	Piano_Init();
	Sound_Init();
	DAC_Init();
	LED_Init();
	EnableInterrupts();

	while(1){
// Insert your code here  
//	DAC_Out(data);
//	data = 0x3F & (data+1); 
		WaitForInterrupt();
  }
}


// Insert subroutines here 
// Inputs: 
// Outputs:
// Notes of functionality 

