// Documentation Section 
// main.c

// Runs on TM4C123 LaunchPad
// Input From: 
// Output to:
//
// 
// Author: Luis Arevalo
// Date: 09/10/2020
// Last modified: 

// 1. Pre-processor Directives Section
// Constant declarations to access port registers using 
// symbolic names instead of addresses
// include directives

#include "tm4c123gh6pm.h"
#include <stdint.h>
#include "PLL.h"
#include "PLL.c"
// 2. Declarations Section
//   Global Variables
uint32_t cycle = 50000;								//# cycles for 1 ms
uint32_t PWM=0; 											//Interger which will have the # of cycles for PWM
//   Insert Function Prototypes here
void PLL_Init(void);
void EnableInterrupts(void);
void WaitForInterrupt(void);
//void SysTick_Init(void);
void PortB_Init (void);
//void Wait(uint32_t delay);
void SysTick_Handler(void);
uint32_t sw = 0;		
void SysTick_Init(void);
// 3. Subroutines Section
void PortB_Init (void){
	int x;
	SYSCTL_RCGCGPIO_R |= 0x02;          // 1) Port B clock
	x=5;
	GPIO_PORTB_AMSEL_R &= ~0x26;				//clear other bit
	GPIO_PORTB_AFSEL_R &= ~0x26;				//clear other bit
	GPIO_PORTB_DEN_R |= 0x26;						//Enable digital I/O on PC1, PC2 and PC5
	GPIO_PORTB_DIR_R |= 0X20;						//PB5 out
	GPIO_PORTB_DIR_R &= ~0X06;					//PB1 and PB2 in
	GPIO_PORTB_PUR_R = 0x06;						//enable pull-up
	
}
void SysTick_Init(void){
	NVIC_ST_CTRL_R = 0;
	NVIC_ST_RELOAD_R = 0x00FFFFFF;			//2^24 - 1 = 16777215, which is the max count number
	NVIC_ST_CURRENT_R = 0;
	NVIC_ST_CTRL_R = 0x07;
}
void SysTick_Handler(void){
				sw = GPIO_PORTB_DATA_R&0x06;
			
				if (sw == 0x00) {
					GPIO_PORTB_DATA_R = 0x00;			//At o Duty cycle output is 0
				}
				
				else if (sw == 0x02){
					PWM = cycle*80/100;						//At 80 Duty cycle, #cycles = 40000; 0x0000 9C40
					if (NVIC_ST_RELOAD_R == PWM-1){
					NVIC_ST_RELOAD_R = 10000-1;
					GPIO_PORTB_DATA_R = 0x20;
				}
					else {
							NVIC_ST_RELOAD_R = 40000-1;
						GPIO_PORTB_DATA_R = 0x00;
						
					}
				}
					
				
				else if (sw == 0x04){
					PWM = cycle*50/100;
					NVIC_ST_RELOAD_R = 25000-1;
					GPIO_PORTB_DATA_R ^= 0x20;

				}
				
				else if (sw == 0x06){
					PWM = cycle*20/100;
					if (NVIC_ST_RELOAD_R == PWM-1){
					NVIC_ST_RELOAD_R = 40000-1;
					GPIO_PORTB_DATA_R = 0x20;
				}
					else {
							NVIC_ST_RELOAD_R = 10000-1;
						GPIO_PORTB_DATA_R = 0x00;
					}
}
				}

// MAIN: Mandatory for a C Program to be executable

int main(void){
	PLL_Init();
	PortB_Init ();
	SysTick_Init ();
	EnableInterrupts();
	SysTick_Handler();
		while(1){
			
			WaitForInterrupt();
		
			}
  }

