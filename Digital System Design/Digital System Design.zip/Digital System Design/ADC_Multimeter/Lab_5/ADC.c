// Provide functions that initialize ADC0 SS3 to be triggered by
// software and trigger a conversion, wait for it to finish,
// and return the result.

#include <stdint.h>
#include "tm4c123gh6pm.h"



void ADC_Init (void){
	SYSCTL_RCGCGPIO_R |= 0x10;     				 // Port E clock
  int x = 5;
  GPIO_PORTE_DIR_R &= ~0x08;      				// PE3 input
	GPIO_PORTE_AFSEL_R |= 0x08;    				 // enable alternate function
  GPIO_PORTE_DEN_R &= ~0x08;     				 // dissable digital I/O
	GPIO_PORTE_AMSEL_R |= 0x08;     			// enable analog function
	SYSCTL_RCGC0_R |= 0x00010000;				//Enable ADC by tunring bit 16 to 1
	x=5;
	SYSCTL_RCGC0_R &= ~0x00000300;				//125k samples/second
	ADC0_SSPRI_R = 0x0123;						//Using sequencer 3, so 3 has highest priority "0"
	ADC0_ACTSS_R &= ~0x0008; 					//Dissable Sequencer 3
  ADC0_EMUX_R &= ~0xF000;						//Sequencer 3 software will trigger
	ADC0_SSMUX3_R &= ~0x000F;					//0000 to Seq 3, step 0 ch0
	ADC0_SSMUX3_R += 0;           				// set channel 0
	ADC0_SSCTL3_R = 0x06;						//0110, only 1 to END & IE
	ADC0_ACTSS_R |= 0x0008; 				    //Enable Seq 3
}
unsigned long ADC_In (void){
	unsigned long Data;								//12-Bit ADC
	ADC0_PSSI_R = 0x08;								//Trigger SS3
	while((ADC0_RIS_R&0x08)==0){};					//Wait for RIS==1
	Data = ADC0_SSFIFO3_R&0xFFF;					//Read
	ADC0_ISC_R = 0x08;								//CLear RIS
	return Data;									//Return Digital Value

}





