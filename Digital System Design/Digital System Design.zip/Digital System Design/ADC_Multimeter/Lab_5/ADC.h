//Function prototypes
#include <stdint.h>
#include "tm4c123gh6pm.h"
void ADC_Init (void);
unsigned long ADC_In (void);



