// Documentation Section 
// main.c

// Runs on TM4C123 LaunchPad
// Input From: 
// Output to:
//
// 
// Author: Enter your name here
// Date: 
// Last modified: 

// 1. Pre-processor Directives Section
// Constant declarations to access port registers using 
// symbolic names instead of addresses
// include directives
#include <stdint.h>
#include "tm4c123gh6pm.h"
#include "PLL.h"
#include "LCD.h"
#include "SysTick.h"
#include "ADC.h"
// 2. Declarations Section
//   Global Variables

unsigned long Data;								//12-Bit ADC
unsigned long ADCMail;						//12-bit sample
int ADCStatus = 0 ;					//New data available FLAG
uint32_t Distance;
uint32_t Di1;
uint32_t Di2;
//   Insert Function Prototypes here

void EnableInterrupts(void);
void DisableInterrupts(void); // Disable interrupts

void Logic_Init(void);
// 3. Subroutines Section
//Set up to analyse logic analyzer
void Logic_Init(void){
	int x;
	SYSCTL_RCGCGPIO_R |= 0x20;          // 1) Port F clock
	x=5;
  GPIO_PORTF_LOCK_R = 0X4C4F434B;   //Unlock GPIO Port F
	GPIO_PORTF_CR_R = 0X1F;						//Allow changes to PF4-0
	GPIO_PORTF_DIR_R |= 0X02;					//PF1 out
	GPIO_PORTF_DIR_R &= ~0X01;				//PF0 in
	GPIO_PORTF_PUR_R = 0x11;					//PF4 and PF0 enable pull-up
	GPIO_PORTF_DEN_R |= 0x1F;					//Enable digital I/O on PF4-PF0
}
// MAIN: Mandatory for a C Program to be executable

int main(void){
// Declare variables here
// Initialize the ports here
	DisableInterrupts();
	PLL_Init();
	ADC_Init();
	LCD_Init();	
	Logic_Init();
	SysTick_Init();
	EnableInterrupts();
	while(1){
// Insert your code here  
		if (ADCStatus==1){

			ADCStatus = 0;
			LCD_Clear();
			if (Distance >= 1000){
			LCD_OutUDec(Di1);
			LCD_OutChar('.');
				if (Di2 < 100){
					LCD_OutChar('.');
					LCD_OutChar('0');
					LCD_OutUDec(Di2);
				}
				else{
					LCD_OutUDec(Di2);
				}
			}
			if (Distance < 1000){
				if (Di2 < 100){
					LCD_OutChar('0');
					LCD_OutChar('.');
					LCD_OutChar('0');
					LCD_OutUDec(Di2);
				}
				else{
					LCD_OutChar('0');
					LCD_OutChar('.');
					LCD_OutUDec(Di2);
				}
			}
		}
		//Data = ADC_In(); //Sample 12-Bit Channel 0
  }
}


// Insert subroutines here 
void SysTick_Handler(void){
	GPIO_PORTF_DATA_R = 0x02;
	ADCMail = ADC_In();
	GPIO_PORTF_DATA_R = 0x00;
	Distance = (171*ADCMail+49385)/256;
	Di1 = Distance/1000;
	Di2 = Distance%1000;
	ADCStatus = 1;
	
}


// Inputs: 
// Outputs:
// Notes of functionality 



