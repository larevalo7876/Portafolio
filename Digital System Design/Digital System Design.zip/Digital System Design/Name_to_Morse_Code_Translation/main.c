// Documentation Section 
// main.c

// Runs on TM4C123 LaunchPad
// Input From: 
// Output to:
//
// 
// Author: Luis Arevalo
// Date: 09/10/2020
// Last modified: 

// 1. Pre-processor Directives Section
// Constant declarations to access port registers using 
// symbolic names instead of addresses
// include directives

#include "tm4c123gh6pm.h"
#include <stdint.h>
// 2. Declarations Section
//   Global Variables
//   Insert Function Prototypes here

void Delay(unsigned long TimeVal);
void Quarter(unsigned long Q);
void L (unsigned long Q);
void U (unsigned long Q);
void I (unsigned long Q);
void S (unsigned long Q);

// 3. Subroutines Section
// MAIN: Mandatory for a C Program to be executable

int main(void){int x;
	SYSCTL_RCGCGPIO_R |= 0x20;          // 1) Port F clock
	x=5;
  GPIO_PORTF_LOCK_R = 0X4C4F434B;   //Unlock GPIO Port F
	GPIO_PORTF_CR_R = 0X1F;						//Allow changes to PF4-0
	GPIO_PORTF_DIR_R |= 0X02;					//PF1 out
	GPIO_PORTF_DIR_R &= ~0X01;				//PF0 in
	GPIO_PORTF_PUR_R = 0x11;					//PF4 and PF0 enable pull-up
	GPIO_PORTF_DEN_R |= 0x1F;					//Enable digital I/O on PF4-PF0
	
	int Q = 2.5*145448; // making Q = 363620, which is 0.25 seconds on Delay function
	int T = 7.5*145448;	// making T = 1090860, which is 0.75 seconds on Delay function
  while(1){
	while ((GPIO_PORTF_DATA_R&0x01) == 0x00){ 			//read PF0 pressed, low
	 x = 5;
		if ((GPIO_PORTF_DATA_R&0x01) == 0x01) {	//read PF0 released, high
		//Call Letter L 
		L(Q);																				
		Delay(Q); // 0.25 second delay between letters
		//Call Letter U 
		U(Q);
		Delay(Q);
		//Call Letter I 
		I(Q);
		Delay(Q);
		//Call Letter S
		S(Q);
	 }
	}
}
}

// Insert subroutines here 
// Inputs: 
// Outputs:
// Notes of functionality 
void Delay(unsigned long TimeVal){
	//TimeVal function for delay
	while(TimeVal){
		TimeVal--;
	}
	}
void Quarter(unsigned long Q) {
	Delay(Q); //Delay function for 0.25 seconds
}
	
void L (unsigned long Q) {
	int T = 7.5*145448;
	//dot
	GPIO_PORTF_DATA_R ^= 0X02;	//on
	Quarter(Q);									//0.25 second delay
	GPIO_PORTF_DATA_R ^= 0X02;	//off
	Quarter(Q);									//0.25 second delay
	
	//_
	GPIO_PORTF_DATA_R ^= 0X02;	//on
	Delay(T);										//0.75 second delay
	GPIO_PORTF_DATA_R ^= 0X02;	//off
	Quarter(Q);									//0.25 second delay
	
	//dot
	GPIO_PORTF_DATA_R ^= 0X02;	//on
	Quarter(Q);									//0.25 second delay
	GPIO_PORTF_DATA_R ^= 0X02;	//off
	Quarter(Q);									//0.25 second delay
	
	//dot
	GPIO_PORTF_DATA_R ^= 0X02;	//on
	Quarter(Q);									//0.25 second delay
	GPIO_PORTF_DATA_R ^= 0X02;	//off
}
void U (unsigned long Q) {
	int T = 7.5*145448;
	
	//dot
	GPIO_PORTF_DATA_R ^= 0X02;	//on
	Quarter(Q);									//0.25 second delay
	GPIO_PORTF_DATA_R ^= 0X02;	//off
	Quarter(Q);									//0.25 second delay
	
	//dot
	GPIO_PORTF_DATA_R ^= 0X02;	//on
	Quarter(Q);									//0.25 second delay
	GPIO_PORTF_DATA_R ^= 0X02;	//off
	Quarter(Q);									//0.25 second delay
	
	//_
	GPIO_PORTF_DATA_R ^= 0X02;	//on
	Delay(T);										//0.75 second delay
	GPIO_PORTF_DATA_R ^= 0X02;	//off
}
void I (unsigned long Q) {
	//dot
	GPIO_PORTF_DATA_R ^= 0X02;	//on
	Quarter(Q);									//0.25 second delay
	GPIO_PORTF_DATA_R ^= 0X02;	//off
	Quarter(Q);									//0.25 second delay
	
	//dot
	GPIO_PORTF_DATA_R ^= 0X02;	//on
	Quarter(Q);									//0.25 second delay
	GPIO_PORTF_DATA_R ^= 0X02;	//off
}
void S (unsigned long Q) {
	int T = 7.5*145448;
	//dot
	GPIO_PORTF_DATA_R ^= 0X02;	//on
	Quarter(Q);									//0.25 second delay
	GPIO_PORTF_DATA_R ^= 0X02;	//off
	Quarter(Q);									//0.25 second delay

	//dot
	GPIO_PORTF_DATA_R ^= 0X02;	//on
	Quarter(Q);									//0.25 second delay
	GPIO_PORTF_DATA_R ^= 0X02;	//off
	Quarter(Q);									//0.25 second delay
	
	//dot
	GPIO_PORTF_DATA_R ^= 0X02;	//on
	Quarter(Q);									//0.25 second delay
	GPIO_PORTF_DATA_R ^= 0X02;	//off
}