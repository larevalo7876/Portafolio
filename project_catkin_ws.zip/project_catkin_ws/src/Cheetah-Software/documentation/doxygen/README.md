# Install doxygen
You can install doxygen with Unbutu command:
```
sudo apt install doxygen
```

# Generate html files
In this folder, execute the following command:
```
doxygen
```
